package constants;

public class Constants {

    //定数（名前）
    public static final String CHECK_CLASS_POCHI = "ポチ";
    public static final String CHECK_CLASS_TAROU = "太郎";
    public static final String CHECK_CLASS_AIBO = "アイボ";
    public static final String CHECK_CLASS_ROBOTAROU = "ロボ太郎";

}