package Animal;

public interface Actions {
	
	public void sayName();

	public void cry();
	
	public void eat();
	
}
