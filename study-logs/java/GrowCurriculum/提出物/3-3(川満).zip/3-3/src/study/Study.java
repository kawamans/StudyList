package study;

/**
 * 3_3 : 課題内容
 *
 * 本課題では、フィールド変数、コンストラクタ、メソッドの基本的な使い方を学んでいきましょう。
 * 課題範囲は以下のとおりです。
 *   Main.java: 問①から問③
 *   Study.java: 問①から問④
 * 指定された値と変数名を守って記述してください。
 *
 */
public class Study {

    // ① 以下のルールに従いフィールド変数を定義しなさい。
    // アクセス修飾子:「private」
    // 変数名: 「msg」
	private String msg;

    // ② 以下のコンストラクタ内で、①で定義した変数 msg に 「"I'm studying Java"」を格納しなさい。
    public Study() {
    		this.msg = "I'm studying Java";
    }

    // ③ 以下のルールに従い文字列を連結してコンソールへ出力するメソッドを定義しなさい。
    // アクセス修飾子: 「protected」
    // メソッド名: 「printConnectedString」
    // 引数 型: 文字列クラス ／ 引数名:「hello」「study」
    protected void printConnectedString(String hello, String study) {
    		System.out.println(hello + study);
    }
    
    // ④ 以下のルールに従いコンソールへ出力するメソッドを定義しなさい。
    // アクセス修飾子: 「protected」
    // メソッド名:「introduce」
    // 出力対象: フィールド変数「msg」
    protected void introduce() {
    		System.out.println(msg);
    }
}

/* コンソール出力結果↓

Hello!Javaカリキュラム
I'm studying Java

 */
