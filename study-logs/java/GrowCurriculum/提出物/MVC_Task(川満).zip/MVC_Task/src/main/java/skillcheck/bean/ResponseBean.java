package skillcheck.bean;

import java.util.List;

/**
 * レスポンス情報Bean（モデル）
 */
public final class ResponseBean {

    /** ・メッセージ */
    private String _message;

    /** ・リクエストステータス */
    private int _requestStatus;

    /** ・社員情報データリスト */
    private List<EmployeeBean> _employeeBeanList;

    /**
     * コンストラクタ
     */
    public ResponseBean() {
    }

    /**
     * コンストラクタ
     */
    public ResponseBean(String message, int requestStatus, List<EmployeeBean> employeeBeanList) {
        this._message = message;
        this._requestStatus = requestStatus;
        this._employeeBeanList = employeeBeanList;
    }

    /**
     * @param message <pre>セットするStringクラスのメッセージ</pre>
     */
    public void setMessage(String message) {
        this._message = message;
    }

    /** @return Stringクラスのメッセージ */
    public String getMessage() {
        return _message;
    }

    /**
     * @param Status <pre>セットするint型のステータス</pre>
     */
    public void setRequestStatus(int requestStatus) {
        this._requestStatus = requestStatus;
    }

    /**
     * @return int型のステータス
     */
    public int getRequestStatus() {
        return _requestStatus;
    }

    /**
     * @param empBean <pre>セットするEmplpoyeeBean型のデータ</pre>
     */
    public void setEmployeeBeanList(List<EmployeeBean> empBeanList) {
        this._employeeBeanList = empBeanList;
    }

    /** @return 社員情報データ */
    public List<EmployeeBean> getEmployeeBeanList() {
        return _employeeBeanList;
    }

}
