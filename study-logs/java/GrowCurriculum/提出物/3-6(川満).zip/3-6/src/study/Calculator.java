package study;

public class Calculator {

    protected static int plus(int a) {
        return a + 1;
    }

    protected static int plus(int a, int b) {
        return a + b;
    }

    protected static int plus(int a, int b, int c) {
        return a + b + c;
    }

}
